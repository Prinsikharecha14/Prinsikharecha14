<?php
$floatnumber="1.200";
ECHO "$floatnumber";
?>