<?php
$num1=20;
$num2=12;
ECHO "$num1"+"$num2";
?>