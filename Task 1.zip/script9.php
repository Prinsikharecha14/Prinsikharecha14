<?php
$nm="DRASHTI";
$city="MORBI";
$cource="MCA";
ECHO "$nm   "."$city   "."$cource";
?>
