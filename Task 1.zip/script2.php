s<?php 
$nm="my name is drashti ";
$age=" i am 21 year old";
Echo"$nm"."$age";
?>