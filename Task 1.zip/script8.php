<?php
$name="drashti rachhadiya<br>";
$age="i m 21 year old<br>";
$city="i m living in morbi<br>";
ECHO "$name"."$age"."$city";  
?>