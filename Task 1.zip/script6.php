<?php
ECHO "<b>HELLO PHP</b><br>";
ECHO "<i>HELLO PHP</i><br>";
ECHO "<h1>HELLO PHP</h1>";

?>

