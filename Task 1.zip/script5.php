<?php
$firstname="DRASHTI";
$lastname="RACHHADIYA";
ECHO "$firstname "."$lastname";
?>