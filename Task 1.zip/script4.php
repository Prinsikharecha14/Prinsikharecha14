<?php
$st1="HELLO ";
$st2=" PHP";
ECHO "$st1"."$st2";
?>